# Employee Portal — CST499 Capstone

A PHP/MySQL course registration portal developed and tested locally with XAMPP. The project provides an employee account workflow and a semester-based course registration system.

## Features
- Landing page, employee registration and login
- Authenticated dashboard with course navigation
- Browse course offerings by semester
- Register for courses, view your schedule, add courses, and drop enrollments
- PDO database connection class, password hashing, prepared statements, CSRF checks and session-based access control

## Technology
PHP 8+, Apache (XAMPP), MySQL/MariaDB, HTML, CSS, and phpMyAdmin.

## Local setup
1. Copy the contents of `application/` into `C:\xampp\htdocs\employee_portal\`.
2. Start Apache and MySQL in the XAMPP Control Panel.
3. In phpMyAdmin, import `database/Employee_Portal_Database.sql`, followed by `database/course_registration.sql` into the `employee_portal` database. **Back up any existing database before importing.**
4. Copy `application/config/database.example.php` to `application/config/database.php` and enter your **local** database settings. Do not commit that file.
5. Visit `http://localhost/employee_portal/` and create a test account.
6. Newly registered accounts may be pending activation; for local testing, activate a fictional test account using your established administration procedure.
7. Log in, open the dashboard, browse courses, register, view your schedule, and drop a class.

## Project layout
- `application/` — PHP pages, reusable connection class, and styles
- `database/` — initial user schema and additive course registration schema
- `documentation/` — assignment documents and UML models (to be added)
- `screenshots/` — project evidence (to be added)

## Verified in the course development workflow
The developer reported successful database import, login, course registration, adding a second course, and dropping one course without removing the other. This repository package has been reviewed structurally but has not been executed against XAMPP in this environment.

## Known scope and follow-up work
The SRS also proposes waitlists, notifications, and profile maintenance; these are not demonstrated as completed in the current application. Before production use, add comprehensive automated tests, secure deployment configuration, and administrative account-approval controls.

## Security
Do not commit actual database credentials, real user data, database dumps containing user records, or local environment files. The sample configuration is a placeholder. XAMPP is intended for local development, not direct public deployment.

## Included capstone documents

- `documentation/srs/Software_Requirements_Specification.docx`
- `documentation/uml/UML_Design_Modeling.docx` and `UML_Diagrams.drawio`
- `documentation/implementation/`: two implementation papers, including embedded figures.

Only the final SRS, UML material, and implementation documentation are included; unrelated weekly assignments are excluded.
