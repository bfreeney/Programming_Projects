-- Additive migration: import AFTER Employee_Portal_Database.sql. Existing users are preserved.
USE employee_portal;
CREATE TABLE IF NOT EXISTS semesters (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(60) NOT NULL UNIQUE,
 starts_on DATE NOT NULL,
 ends_on DATE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS courses (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 code VARCHAR(20) NOT NULL UNIQUE,
 title VARCHAR(150) NOT NULL,
 credits TINYINT UNSIGNED NOT NULL DEFAULT 3,
 description TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS course_offerings (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 course_id INT UNSIGNED NOT NULL,
 semester_id INT UNSIGNED NOT NULL,
 capacity SMALLINT UNSIGNED NOT NULL DEFAULT 25,
 UNIQUE KEY uq_course_semester (course_id,semester_id),
 FOREIGN KEY (course_id) REFERENCES courses(id),
 FOREIGN KEY (semester_id) REFERENCES semesters(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS enrollments (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NOT NULL,
 offering_id INT UNSIGNED NOT NULL,
 enrolled_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_user_offering (user_id,offering_id),
 FOREIGN KEY (user_id) REFERENCES users(id),
 FOREIGN KEY (offering_id) REFERENCES course_offerings(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Fictional demonstration catalog. INSERT IGNORE makes repeat imports non-destructive.
INSERT IGNORE INTO semesters (name,starts_on,ends_on) VALUES
 ('Spring 2027','2027-01-11','2027-05-07'),('Summer 2027','2027-05-24','2027-08-06'),('Fall 2027','2027-08-23','2027-12-10');
INSERT IGNORE INTO courses (code,title,credits,description) VALUES
 ('CIS101','Introduction to Information Systems',3,'Explore information systems and workplace technology.'),
 ('WEB201','Dynamic Web Development',3,'Build database-connected websites with PHP.'),
 ('DB202','Database Design',3,'Model relational data and write SQL queries.'),
 ('SEC210','Application Security',3,'Apply authentication and secure development practices.'),
 ('SWE301','Software Engineering',3,'Study requirements, design, implementation, and testing.'),
 ('NET205','Networking Fundamentals',3,'Understand network protocols and infrastructure.');
INSERT IGNORE INTO course_offerings (course_id,semester_id,capacity)
 SELECT c.id,s.id,25 FROM courses c CROSS JOIN semesters s
 WHERE (s.name='Spring 2027' AND c.code IN ('CIS101','WEB201','DB202','SWE301'))
 OR (s.name='Summer 2027' AND c.code IN ('CIS101','SEC210','NET205'))
 OR (s.name='Fall 2027' AND c.code IN ('WEB201','DB202','SEC210','SWE301','NET205'));
