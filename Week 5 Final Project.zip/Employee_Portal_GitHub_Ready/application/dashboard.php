<?php

declare(strict_types=1);
session_start(['cookie_httponly' => true, 'cookie_samesite' => 'Lax', 'use_strict_mode' => true]);
header('Cache-Control: no-store, no-cache, must-revalidate');
if (empty($_SESSION['user_id'])) {
    header('Location: login.php', true, 303);
    exit;
}
function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
$name = (string) ($_SESSION['display_name'] ?? 'Employee');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Employee Portal | Dashboard</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/login.css">
    <style>
        .dashboard-content { padding-top: 2.5rem; padding-bottom: 4rem; }
        .dashboard-welcome { margin-bottom: 2rem; }
        .dashboard-welcome p { max-width: 650px; }
        .dashboard-courses { background: #fff; border: 1px solid #e9e5f2; border-radius: 18px; padding: clamp(1.25rem, 3vw, 2rem); box-shadow: 0 8px 28px rgba(35, 20, 80, .06); }
        .dashboard-section-heading h2 { color: #553c9a; margin: .55rem 0; }
        .dashboard-section-heading p { color: #646174; margin: 0 0 1.5rem; }
        .dashboard-action-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 1rem; }
        .dashboard-action-card { display: flex; flex-direction: column; gap: .65rem; padding: 1.5rem; border-radius: 14px; border: 1px solid #e5def5; background: #f8f6fd; text-decoration: none; color: #29243b; transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease; }
        .dashboard-action-card:hover { transform: translateY(-2px); border-color: #9e8acb; box-shadow: 0 8px 20px rgba(85, 60, 154, .12); }
        .dashboard-action-card:focus-visible { outline: 3px solid #553c9a; outline-offset: 3px; }
        .dashboard-action-icon { font-size: 1.8rem; line-height: 1.2; }
        .dashboard-action-title { font-size: 1.2rem; font-weight: 700; color: #553c9a; }
        .dashboard-action-description { color: #625d70; line-height: 1.5; flex: 1; }
        .dashboard-action-link { font-weight: 700; color: #553c9a; margin-top: .5rem; }
        @media (max-width: 680px) { .dashboard-action-grid { grid-template-columns: 1fr; } }
    </style>
</head>

<body>
    <header class="site-header">
        <div class="container nav-wrap"><a class="brand" href="index.php"><span class="brand-icon">EP</span><span>Employee<span class="brand-accent">Portal</span></span></a>
            <nav class="nav-links"><a href="index.php">Home</a>
                <form method="post" action="logout.php"><input type="hidden" name="csrf_token" value="<?= e($_SESSION['logout_csrf'] ??= bin2hex(random_bytes(32))) ?>"><button class="btn btn-small" type="submit">Log Out</button></form>
            </nav>
        </div>
    </header>
    <main class="login-main">
        <div class="container dashboard-content">
            <section class="dashboard-welcome" aria-labelledby="welcome-heading">
                <span class="card-kicker">EMPLOYEE DASHBOARD</span>
                <h1 id="welcome-heading">Welcome, <?= e($name) ?>.</h1>
                <p>You are securely signed in to Employee Portal. Manage your classes and semester schedule below.</p>
            </section>

            <section class="dashboard-courses" aria-labelledby="courses-heading">
                <div class="dashboard-section-heading">
                    <span class="card-kicker">YOUR ACADEMIC WORKSPACE</span>
                    <h2 id="courses-heading">Course Registration &amp; Scheduling</h2>
                    <p>Find classes for the semester, register for courses, and review your current schedule.</p>
                </div>
                <div class="dashboard-action-grid">
                    <a class="dashboard-action-card" href="courses.php">
                        <span class="dashboard-action-icon" aria-hidden="true">&#128218;</span>
                        <span class="dashboard-action-title">Browse &amp; Register</span>
                        <span class="dashboard-action-description">Explore available courses and add classes to your semester.</span>
                        <span class="dashboard-action-link">View Course Catalog &rarr;</span>
                    </a>
                    <a class="dashboard-action-card" href="my_schedule.php">
                        <span class="dashboard-action-icon" aria-hidden="true">&#128197;</span>
                        <span class="dashboard-action-title">My Schedule</span>
                        <span class="dashboard-action-description">See your registered classes and drop courses when needed.</span>
                        <span class="dashboard-action-link">Manage My Schedule &rarr;</span>
                    </a>
                </div>
            </section>
        </div>
    </main>
</body>
</html>
