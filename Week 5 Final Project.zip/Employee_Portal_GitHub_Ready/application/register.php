<?php
declare(strict_types=1);
session_start();
if (empty($_SESSION['registration_csrf'])) {
    $_SESSION['registration_csrf'] = bin2hex(random_bytes(32));
}
$fields = ['employee_id', 'first_name', 'last_name', 'email', 'username'];
$values = array_fill_keys($fields, '');
$errors = [];
$success = isset($_GET['registered']) && $_GET['registered'] === '1';
function e(string $value): string { return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($fields as $field) {
        $values[$field] = trim((string)($_POST[$field] ?? ''));
    }
    $password = (string)($_POST['password'] ?? '');
    $confirmation = (string)($_POST['confirm_password'] ?? '');
    if (!hash_equals($_SESSION['registration_csrf'], (string)($_POST['csrf_token'] ?? ''))) {
        $errors['general'] = 'Your session expired. Refresh the page and try again.';
    }
    foreach (['employee_id' => 20, 'first_name' => 50, 'last_name' => 50, 'email' => 150, 'username' => 50] as $key => $limit) {
        if ($values[$key] === '' || mb_strlen($values[$key]) > $limit) {
            $errors[$key] = 'This field is required and must be no longer than ' . $limit . ' characters.';
        }
    }
    if (!isset($errors['employee_id']) && !preg_match('/^[A-Za-z0-9-]{3,20}$/', $values['employee_id'])) $errors['employee_id'] = 'Use 3–20 letters, numbers, or hyphens.';
    foreach (['first_name', 'last_name'] as $nameField) {
        if (!isset($errors[$nameField]) && !preg_match("/^[\p{L}][\p{L} .'-]*$/u", $values[$nameField])) $errors[$nameField] = 'Enter a valid name.';
    }
    if (!isset($errors['email']) && !filter_var($values['email'], FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Enter a valid email address.';
    if (!isset($errors['username']) && !preg_match('/^[A-Za-z0-9_]{3,50}$/', $values['username'])) $errors['username'] = 'Use 3–50 letters, numbers, or underscores.';
    if (strlen($password) < 12 || strlen($password) > 72) $errors['password'] = 'Use a password between 12 and 72 characters.';
    if ($password !== $confirmation) $errors['confirm_password'] = 'Passwords do not match.';
    if (!$errors) {
        try {
            require_once __DIR__ . '/app/Database.php';
            $config = require __DIR__ . '/config/database.php';
            $pdo = (new Database($config))->getConnection();
            $stmt = $pdo->prepare('INSERT INTO users (employee_id, first_name, last_name, email, username, password_hash) VALUES (:employee_id, :first_name, :last_name, :email, :username, :password_hash)');
            $stmt->execute([
                ':employee_id' => $values['employee_id'],
                ':first_name' => $values['first_name'],
                ':last_name' => $values['last_name'],
                ':email' => $values['email'],
                ':username' => $values['username'],
                ':password_hash' => password_hash($password, PASSWORD_DEFAULT),
            ]);
            $_SESSION['registration_csrf'] = bin2hex(random_bytes(32));
            header('Location: register.php?registered=1', true, 303);
            exit;
        } catch (PDOException $exception) {
            error_log('Employee registration database error: ' . $exception->getMessage());
            if ($exception->getCode() === '23000') {
                $errors['general'] = 'An account with that employee ID, email, or username already exists.';
            } else {
                $errors['general'] = 'Registration is temporarily unavailable. Please try again later.';
            }
        } catch (Throwable $exception) {
            error_log('Employee registration error: ' . $exception->getMessage());
            $errors['general'] = 'Registration is temporarily unavailable. Please try again later.';
        }
    }
}
$labels = ['employee_id'=>'Employee ID', 'first_name'=>'First name', 'last_name'=>'Last name', 'email'=>'Email address', 'username'=>'Username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Create your Employee Portal account.">
  <title>Employee Portal | Create Account</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/register.css">
</head>
<body>
<a class="skip-link" href="#main-content">Skip to content</a>
<header class="site-header"><div class="container nav-wrap">
<a class="brand" href="index.php"><span class="brand-icon" aria-hidden="true">EP</span><span>Employee<span class="brand-accent">Portal</span></span></a>
<nav class="nav-links" aria-label="Main navigation"><a href="index.php">Home</a><a href="index.php#features">Features</a><a href="index.php#about">About</a><a class="nav-login" href="login.php">Log In</a><a class="btn btn-small active" href="register.php" aria-current="page">Create Account</a></nav>
</div></header>
<main id="main-content" class="register-main"><div class="container register-layout">
<section class="register-intro" aria-label="Registration introduction"><span class="eyebrow"><span class="status-dot"></span> YOUR WORKSPACE STARTS HERE</span><h1>Join your <span>employee workspace.</span></h1><p>Create your account to access a simpler, more organized employee experience.</p><div class="intro-points"><p><span aria-hidden="true">✓</span> One secure employee profile</p><p><span aria-hidden="true">✓</span> Easy access to workplace resources</p><p><span aria-hidden="true">✓</span> Consistent, straightforward navigation</p></div><div class="intro-note">Accounts are submitted for review before they can be activated.</div></section>
<section class="registration-card" aria-labelledby="register-title"><div class="card-heading"><span class="card-kicker">NEW EMPLOYEE ACCOUNT</span><h2 id="register-title">Create your account</h2><p>Enter your details below to get started.</p></div>
<?php if ($success): ?><div class="notice notice-success" role="status">Registration submitted successfully. Your account is pending activation.</div><?php endif; ?>
<?php if (isset($errors['general'])): ?><div class="notice notice-error" role="alert"><?= e($errors['general']) ?></div><?php endif; ?>
<form method="post" action="register.php" class="registration-form">
<input type="hidden" name="csrf_token" value="<?= e($_SESSION['registration_csrf']) ?>">
<div class="form-grid">
<?php foreach ($labels as $key => $label): ?>
<div class="field <?= $key === 'email' ? 'field-full' : '' ?>"><label for="<?= e($key) ?>"><?= e($label) ?> <span aria-hidden="true">*</span></label><input id="<?= e($key) ?>" name="<?= e($key) ?>" type="<?= $key === 'email' ? 'email' : 'text' ?>" value="<?= e($values[$key]) ?>" maxlength="<?= $key === 'email' ? '150' : ($key === 'employee_id' ? '20' : '50') ?>" autocomplete="<?= $key === 'email' ? 'email' : ($key === 'first_name' ? 'given-name' : ($key === 'last_name' ? 'family-name' : ($key === 'username' ? 'username' : 'off'))) ?>" required <?= isset($errors[$key]) ? 'aria-invalid="true" aria-describedby="error-' . e($key) . '"' : '' ?>><span class="field-error" id="error-<?= e($key) ?>"><?= e($errors[$key] ?? '') ?></span></div>
<?php endforeach; ?>
<div class="field"><label for="password">Password <span aria-hidden="true">*</span></label><input id="password" name="password" type="password" minlength="12" maxlength="72" autocomplete="new-password" required <?= isset($errors['password']) ? 'aria-invalid="true" aria-describedby="error-password"' : '' ?>><span class="field-hint">At least 12 characters.</span><span class="field-error" id="error-password"><?= e($errors['password'] ?? '') ?></span></div>
<div class="field"><label for="confirm_password">Confirm password <span aria-hidden="true">*</span></label><input id="confirm_password" name="confirm_password" type="password" autocomplete="new-password" required <?= isset($errors['confirm_password']) ? 'aria-invalid="true" aria-describedby="error-confirm_password"' : '' ?>><span class="field-error" id="error-confirm_password"><?= e($errors['confirm_password'] ?? '') ?></span></div>
</div><button type="submit" class="btn btn-primary submit-button">Create Account <span aria-hidden="true">→</span></button><p class="form-footer">Already have an account? <a href="login.php">Log in</a></p></form>
</section></div></main>
<footer class="site-footer"><div class="container footer-content"><span>© <?= date('Y') ?> Employee Portal. All rights reserved.</span><span>Built for a better employee experience.</span></div></footer>
</body></html>
