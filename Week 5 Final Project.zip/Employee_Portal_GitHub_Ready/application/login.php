<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start(['cookie_httponly' => true, 'cookie_samesite' => 'Lax', 'use_strict_mode' => true]);
}
if (!empty($_SESSION['user_id'])) {
    header('Location: dashboard.php', true, 303);
    exit;
}
if (empty($_SESSION['login_csrf'])) {
    $_SESSION['login_csrf'] = bin2hex(random_bytes(32));
}
function escape(string $value): string { return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
$error = '';
$username = '';
$attempts = $_SESSION['login_attempts'] ?? [];
$attempts = array_values(array_filter($attempts, static fn($time) => is_int($time) && $time > time() - 900));
$_SESSION['login_attempts'] = $attempts;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    if (!hash_equals($_SESSION['login_csrf'], (string) ($_POST['csrf_token'] ?? ''))) {
        $error = 'Your session expired. Refresh the page and try again.';
    } elseif (count($attempts) >= 5) {
        $error = 'Too many login attempts. Please try again in 15 minutes.';
    } elseif ($username === '' || $password === '') {
        $error = 'Enter your username and password.';
    } else {
        try {
            require_once __DIR__ . '/app/Database.php';
            $config = require __DIR__ . '/config/database.php';
            $pdo = (new Database($config))->getConnection();
            $stmt = $pdo->prepare('SELECT id, username, first_name, last_name, role, account_status, password_hash FROM users WHERE username = :username LIMIT 1');
            $stmt->execute([':username' => $username]);
            $user = $stmt->fetch();
            if (!$user || !password_verify($password, $user['password_hash'])) {
                $_SESSION['login_attempts'][] = time();
                $error = 'Invalid username or password.';
            } elseif ($user['account_status'] !== 'active') {
                $error = 'Your account is not active. Contact the portal administrator.';
            } else {
                session_regenerate_id(true);
                $_SESSION['user_id'] = (int) $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['display_name'] = $user['first_name'] . ' ' . $user['last_name'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['login_attempts'] = [];
                $_SESSION['login_csrf'] = bin2hex(random_bytes(32));
                $update = $pdo->prepare('UPDATE users SET last_login_at = NOW() WHERE id = :id');
                $update->execute([':id' => $user['id']]);
                header('Location: dashboard.php', true, 303);
                exit;
            }
        } catch (Throwable $exception) {
            error_log('Employee login error: ' . $exception->getMessage());
            $error = 'Login is temporarily unavailable. Please try again later.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="description" content="Sign in to your Employee Portal account."><title>Employee Portal | Log In</title><link rel="stylesheet" href="assets/css/style.css"><link rel="stylesheet" href="assets/css/login.css"></head>
<body><a class="skip-link" href="#main-content">Skip to content</a>
<header class="site-header"><div class="container nav-wrap"><a class="brand" href="index.php"><span class="brand-icon" aria-hidden="true">EP</span><span>Employee<span class="brand-accent">Portal</span></span></a><nav class="nav-links" aria-label="Main navigation"><a href="index.php">Home</a><a href="index.php#features">Features</a><a href="index.php#about">About</a><a class="nav-login active" href="login.php" aria-current="page">Log In</a><a class="btn btn-small" href="register.php">Create Account</a></nav></div></header>
<main id="main-content" class="login-main"><div class="container login-layout"><section class="login-intro"><span class="eyebrow"><span class="status-dot"></span> YOUR EMPLOYEE WORKSPACE</span><h1>Welcome <span>back.</span></h1><p>Everything you need for a more organized workday starts here. Sign in securely to access your employee workspace.</p><div class="login-highlights"><p><span aria-hidden="true">✓</span> Your employee profile in one place</p><p><span aria-hidden="true">✓</span> A simple, secure sign-in experience</p><p><span aria-hidden="true">✓</span> Easy access to your portal dashboard</p></div><div class="login-note">New registrations require account activation before the first login.</div></section>
<section class="login-card" aria-labelledby="login-title"><span class="card-kicker">EMPLOYEE ACCESS</span><h2 id="login-title">Sign in to your account</h2><p class="card-description">Enter your username and password to continue.</p>
<?php if ($error !== ''): ?><div class="login-alert" role="alert"><?= escape($error) ?></div><?php endif; ?>
<form method="post" action="login.php" class="login-form"><input type="hidden" name="csrf_token" value="<?= escape($_SESSION['login_csrf']) ?>"><div class="login-field"><label for="username">Username</label><input type="text" id="username" name="username" autocomplete="username" maxlength="50" value="<?= escape($username) ?>" required></div><div class="login-field"><label for="password">Password</label><input type="password" id="password" name="password" autocomplete="current-password" required></div><button type="submit" class="btn btn-primary login-submit">Log In <span aria-hidden="true">→</span></button></form>
<p class="login-footer">New to Employee Portal? <a href="register.php">Create an account</a></p><div class="security-hint">🔒 Your password is verified securely and is never displayed.</div></section></div></main>
<footer class="site-footer"><div class="container footer-content"><span>© <?= date('Y') ?> Employee Portal. All rights reserved.</span><span>Built for a better employee experience.</span></div></footer></body></html>
