<?php
// Employee Portal landing page. Future authentication can set $_SESSION['user_id'].
session_start();
$isLoggedIn = isset($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Employee Portal — a central place for employee resources and account access.">
  <title>Employee Portal | Welcome</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to content</a>
  <header class="site-header">
    <div class="container nav-wrap">
      <a class="brand" href="index.php" aria-label="Employee Portal home"><span class="brand-icon" aria-hidden="true">EP</span><span>Employee<span class="brand-accent">Portal</span></span></a>
      <nav class="nav-links" aria-label="Main navigation">
        <a class="active" href="index.php" aria-current="page">Home</a>
        <a href="#features">Features</a>
        <a href="#about">About</a>
        <a class="nav-login" href="login.php">Log In</a>
        <a class="btn btn-small" href="register.php">Create Account</a>
      </nav>
    </div>
  </header>

  <main id="main-content">
    <section class="hero">
      <div class="container hero-grid">
        <div class="hero-content">
          <span class="eyebrow"><span class="status-dot"></span> YOUR WORKSPACE, SIMPLIFIED</span>
          <h1>Everything you need to <span>stay connected.</span></h1>
          <p>A secure, organized home for employee access and essential workplace resources. Get started in just a few clicks.</p>
          <div class="hero-actions">
            <a class="btn btn-primary" href="register.php">Get Started <span aria-hidden="true">→</span></a>
            <a class="btn btn-outline" href="login.php">Employee Log In</a>
          </div>
          <div class="hero-note"><span class="checkmark" aria-hidden="true">✓</span> Simple account setup <span class="separator">·</span> <span class="checkmark" aria-hidden="true">✓</span> Designed for employees</div>
        </div>
        <div class="dashboard-illustration" aria-label="Illustration of a sample employee dashboard">
          <div class="dashboard-top"><div class="dashboard-logo">EP</div><div><strong>Employee Dashboard</strong><small>Workspace overview</small></div><span class="demo-tag">PREVIEW</span></div>
          <div class="dashboard-greeting"><small>WELCOME TO YOUR WORKSPACE</small><h2>Good to see you! <span aria-hidden="true">✳</span></h2><p>Your employee resources, all in one place.</p></div>
          <div class="dashboard-cards"><div class="mini-card"><span class="mini-icon purple" aria-hidden="true">▦</span><strong>My Profile</strong><small>Account details</small></div><div class="mini-card"><span class="mini-icon blue" aria-hidden="true">▤</span><strong>Resources</strong><small>Helpful information</small></div><div class="mini-card"><span class="mini-icon green" aria-hidden="true">✓</span><strong>Quick Access</strong><small>One central hub</small></div></div>
          <div class="dashboard-bottom"><span class="online-dot"></span> Portal preview <span>Designed for productivity</span></div>
        </div>
      </div>
    </section>

    <section class="features" id="features">
      <div class="container"><div class="section-heading"><span class="section-kicker">BUILT AROUND YOU</span><h2>A better way to work</h2><p>A streamlined experience that makes accessing your workplace tools easier.</p></div>
        <div class="feature-grid">
          <article class="feature-card"><div class="feature-icon lavender" aria-hidden="true">▣</div><h3>One Central Location</h3><p>Find employee information and resources without switching between disconnected systems.</p></article>
          <article class="feature-card"><div class="feature-icon sky" aria-hidden="true">♙</div><h3>Your Personal Account</h3><p>Create an account and access a workspace tailored to your employee profile.</p></article>
          <article class="feature-card"><div class="feature-icon mint" aria-hidden="true">◇</div><h3>Built for Simplicity</h3><p>Navigate a clean, intuitive interface designed to make everyday tasks feel effortless.</p></article>
        </div>
      </div>
    </section>

    <section class="cta-section" id="about"><div class="container"><div class="cta-box"><div><span class="section-kicker light">READY WHEN YOU ARE</span><h2>Make your workday easier.</h2><p>Create your employee account to get started with the portal.</p></div><a class="btn btn-white" href="register.php">Create Your Account <span aria-hidden="true">→</span></a></div></div></section>
  </main>
  <footer class="site-footer"><div class="container footer-content"><span>© <?php echo date('Y'); ?> Employee Portal. All rights reserved.</span><span>Built for a better employee experience.</span></div></footer>
</body>
</html>
