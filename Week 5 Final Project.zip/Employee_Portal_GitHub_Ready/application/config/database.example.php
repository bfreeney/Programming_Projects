<?php
/** Copy to database.php and update for your local XAMPP environment. */
return [
    'host' => '127.0.0.1',
    'port' => 3306,
    'database' => 'employee_portal',
    'username' => 'YOUR_DB_USERNAME',
    'password' => 'YOUR_DB_PASSWORD',
];
