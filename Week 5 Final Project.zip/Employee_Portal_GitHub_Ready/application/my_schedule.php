<?php
require_once __DIR__.'/course_common.php';
$userId=(int)$_SESSION['user_id'];$message='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!hash_equals($_SESSION['course_csrf'],(string)($_POST['csrf_token']??''))){http_response_code(403);exit('Invalid form token.');}
 $id=filter_input(INPUT_POST,'enrollment_id',FILTER_VALIDATE_INT);
 if($id){$stmt=$pdo->prepare('DELETE FROM enrollments WHERE id=? AND user_id=?');$stmt->execute([$id,$userId]);$message=$stmt->rowCount()?'Class removed from your schedule.':'Enrollment not found.';}
}
$stmt=$pdo->prepare('SELECT e.id,c.code,c.title,c.credits,s.name AS semester,s.starts_on FROM enrollments e JOIN course_offerings co ON co.id=e.offering_id JOIN courses c ON c.id=co.course_id JOIN semesters s ON s.id=co.semester_id WHERE e.user_id=? ORDER BY s.starts_on,c.code');$stmt->execute([$userId]);$rows=$stmt->fetchAll();
page_top('My Class Schedule');if($message)echo '<p class="course-message">'.h($message).'</p>';
?><section class="course-panel"><p>View your registered classes, add more courses, or remove a class.</p><p><a href="courses.php">Browse available courses</a></p><div class="course-scroll"><table class="course-table"><thead><tr><th>Semester</th><th>Code</th><th>Course</th><th>Credits</th><th>Action</th></tr></thead><tbody><?php $total=0;foreach($rows as $r):$total+=(int)$r['credits'];?><tr><td><?=h($r['semester'])?></td><td><?=h($r['code'])?></td><td><?=h($r['title'])?></td><td><?=h($r['credits'])?></td><td><form method="post" onsubmit="return confirm('Remove this class from your schedule?')"><input type="hidden" name="csrf_token" value="<?=h($_SESSION['course_csrf'])?>"><input type="hidden" name="enrollment_id" value="<?=h($r['id'])?>"><button class="course-button">Drop Class</button></form></td></tr><?php endforeach;?></tbody></table></div><p><strong>Total registered credits: <?=h($total)?></strong></p><?php if(!$rows)echo '<p>You have not registered for any classes yet.</p>';?></section><?php page_bottom(); ?>
