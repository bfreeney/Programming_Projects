<?php
declare(strict_types=1);
session_start(['cookie_httponly'=>true,'cookie_samesite'=>'Lax','use_strict_mode'=>true]);
header('Cache-Control: no-store, no-cache, must-revalidate');
if (empty($_SESSION['user_id'])) { header('Location: login.php',true,303); exit; }
require_once __DIR__.'/app/Database.php';
$config=require __DIR__.'/config/database.php';
try { $pdo=(new Database($config))->getConnection(); }
catch (Throwable $ex) { error_log($ex->getMessage()); http_response_code(500); exit('Database temporarily unavailable.'); }
function h($s): string { return htmlspecialchars((string)$s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
if (empty($_SESSION['course_csrf'])) $_SESSION['course_csrf']=bin2hex(random_bytes(32));
function page_top(string $title): void { ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=h($title)?> | Employee Portal</title><link rel="stylesheet" href="assets/css/style.css"><style>
.course-shell{max-width:1050px;margin:45px auto;padding:0 20px}.course-panel{background:#fff;border:1px solid #e5e1f0;border-radius:16px;padding:24px;margin:22px 0;box-shadow:0 8px 24px #24164c0b}.course-table{width:100%;border-collapse:collapse}.course-table th,.course-table td{text-align:left;padding:13px 10px;border-bottom:1px solid #eae7f1}.course-table th{color:#51427c}.course-actions{display:flex;gap:12px;align-items:center;flex-wrap:wrap}.course-button{background:#6540b4;color:#fff;border:0;border-radius:8px;padding:10px 15px;cursor:pointer}.course-button:disabled{background:#a7a0b5;cursor:not-allowed}.course-message{background:#f0ecfa;padding:14px;border-radius:9px}.course-nav{display:flex;gap:20px;flex-wrap:wrap}.course-nav a{color:#6241a5}.course-scroll{overflow-x:auto}select{padding:9px;border-radius:7px;border:1px solid #b9b2c8}@media(max-width:650px){.course-table{font-size:13px}}
</style></head><body><main class="course-shell"><div class="course-nav"><a href="dashboard.php">Dashboard</a><a href="courses.php">Course Catalog</a><a href="my_schedule.php">My Schedule</a></div><h1><?=h($title)?></h1>
<?php }
function page_bottom(): void { echo '</main></body></html>'; }
