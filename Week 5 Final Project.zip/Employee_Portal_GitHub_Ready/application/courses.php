<?php
require_once __DIR__.'/course_common.php';
$userId=(int)$_SESSION['user_id'];
$message='';
$semesters=$pdo->query('SELECT id,name FROM semesters ORDER BY starts_on')->fetchAll();
$semesterId=filter_input(INPUT_GET,'semester',FILTER_VALIDATE_INT) ?: (int)($semesters[0]['id']??0);
if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (!hash_equals($_SESSION['course_csrf'],(string)($_POST['csrf_token']??''))) { http_response_code(403); exit('Invalid form token.'); }
  $offeringId=filter_input(INPUT_POST,'offering_id',FILTER_VALIDATE_INT);
  if (!$offeringId) $message='Invalid course selection.';
  else {
    try {
      $pdo->beginTransaction();
      $stmt=$pdo->prepare('SELECT capacity,semester_id FROM course_offerings WHERE id=? FOR UPDATE');
      $stmt->execute([$offeringId]); $offering=$stmt->fetch();
      if (!$offering) { $message='Course offering not found.'; }
      else {
        $semesterId=(int)$offering['semester_id'];
        $stmt=$pdo->prepare('SELECT COUNT(*) FROM enrollments WHERE offering_id=?');$stmt->execute([$offeringId]);$count=(int)$stmt->fetchColumn();
        $stmt=$pdo->prepare('SELECT COUNT(*) FROM enrollments WHERE user_id=? AND offering_id=?');$stmt->execute([$userId,$offeringId]);$already=(int)$stmt->fetchColumn();
        if ($already) $message='You are already registered for this course.';
        elseif ($count >= (int)$offering['capacity']) $message='This class is full.';
        else { $stmt=$pdo->prepare('INSERT INTO enrollments(user_id,offering_id) VALUES(?,?)');$stmt->execute([$userId,$offeringId]);$message='Registration successful!'; }
      }
      $pdo->commit();
    } catch(Throwable $ex) { if($pdo->inTransaction())$pdo->rollBack();error_log($ex->getMessage());$message='Could not register. Please try again.'; }
  }
}
$stmt=$pdo->prepare('SELECT co.id,c.code,c.title,c.credits,c.description,co.capacity,(SELECT COUNT(*) FROM enrollments e WHERE e.offering_id=co.id) AS taken,EXISTS(SELECT 1 FROM enrollments e WHERE e.offering_id=co.id AND e.user_id=?) AS registered FROM course_offerings co JOIN courses c ON c.id=co.course_id WHERE co.semester_id=? ORDER BY c.code');
$stmt->execute([$userId,$semesterId]);$courses=$stmt->fetchAll();
page_top('Course Catalog');
if($message)echo '<p class="course-message">'.h($message).'</p>';
?>
<section class="course-panel"><form method="get" class="course-actions"><label for="semester">Select semester</label><select id="semester" name="semester"><?php foreach($semesters as $s):?><option value="<?=h($s['id'])?>" <?=$semesterId==(int)$s['id']?'selected':''?>><?=h($s['name'])?></option><?php endforeach;?></select><button class="course-button">Show Courses</button></form></section>
<section class="course-panel course-scroll"><table class="course-table"><thead><tr><th>Code</th><th>Course</th><th>Credits</th><th>Seats</th><th>Action</th></tr></thead><tbody><?php foreach($courses as $c):?><tr><td><?=h($c['code'])?></td><td><strong><?=h($c['title'])?></strong><div><?=h($c['description'])?></div></td><td><?=h($c['credits'])?></td><td><?=h((int)$c['capacity']-(int)$c['taken'])?> available</td><td><?php if($c['registered']):?>Registered<?php else:?><form method="post"><input type="hidden" name="csrf_token" value="<?=h($_SESSION['course_csrf'])?>"><input type="hidden" name="offering_id" value="<?=h($c['id'])?>"><button class="course-button" <?=((int)$c['taken']>=(int)$c['capacity'])?'disabled':''?>>Register</button></form><?php endif;?></td></tr><?php endforeach;?></tbody></table><?php if(!$courses)echo '<p>No classes are listed for this semester.</p>';?></section>
<?php page_bottom(); ?>
