Add redacted screenshots of the running portal, schema, and enrollment tests here.
