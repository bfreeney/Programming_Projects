# Capstone documentation

- `srs/`: final Software Requirements Specification.
- `uml/`: UML design modeling paper and editable Draw.io diagrams.
- `implementation/`: landing/login/registration development and database/course-registration implementation documentation.

The design documents include planned features (such as waitlists) that may not be implemented in the submitted application.
